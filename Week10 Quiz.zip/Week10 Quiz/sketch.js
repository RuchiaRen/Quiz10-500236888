// Global variables for rectangles, the song, fft analysis, and lerp amount
let rectangles = [];
let song;
let fft;
let lerpAmount;

// Preload function to ensure the song is loaded before the sketch starts
function preload() {
  song = loadSound("audio/sample-visualisation.mp3");
}

function setup() {
  createCanvas(800, 800);

  // Initialize FFT with 0.8 smoothing and 16 bins
  fft = new p5.FFT(0.8, 16);

  // Distribute rectangles evenly around a circle centered in the canvas
  let angle = TWO_PI / 24;
  for (let i = 0; i < 24; i++) {
    let x = width / 2 + 300 * cos(angle * i);
    let y = height / 2 + 300 * sin(angle * i);
    let colour = color(random(255), random(255), random(255));
    rectangles.push(new Rectangle(x, y, colour));
  }

  // Connect the song to FFT for analysis
  song.connect(fft);
}

function draw() {
  // Check if audio context is running, if not show the instructions
  if (getAudioContext().state !== "running") {
    background(0);
    fill(255);
    textSize(24); // Make the instruction text bigger
    textAlign(CENTER, CENTER); // Center the instruction text
    text("Tap here to start sound playback", width / 2, height / 2);
    return;
  }

  background(255, 180, 180);

  // Analyze the song to get spectrum data
  let spectrum = fft.analyze();

  // Dynamically set the lerp amount based on mouse X position
  lerpAmount = map(mouseX, 0, width, 0, 1);

  // Display each rectangle with amplitude data
  for (let i = 0; i < rectangles.length; i++) {
    rectangles[i].display(spectrum[i]);
  }
}

// Function to handle mouse press events for starting and stopping the song
function mousePressed() {
  if (song.isPlaying()) {
    song.stop();
    background(255, 0, 0);
  } else {
    song.play();
    background(0, 255, 0);
  }
}

// Class definition for the Rectangle
class Rectangle {
  constructor(x, y, colour) {
    this.x = x;
    this.y = y;
    this.currentSize = 0; // Size of the rectangle (changes with amplitude)
    this.colour = colour;
    this.rotation = 0;
  }

  // Display method to show the rectangle on the canvas
  display(amp) {
    // Map amplitude (0-255) to a target size (0-100)
    let targetSize = map(amp, 0, 255, 0, 100);
    this.currentSize = lerp(this.currentSize, targetSize, lerpAmount);

    // Adjust rotation based on amplitude
    this.rotation = lerp(this.rotation, targetSize / 100, lerpAmount);

    // Change color based on amplitude
    this.colour.setAlpha(amp);

    push(); // Save current drawing state
    translate(this.x, this.y); // Move origin to rectangle's position
    rotate(this.rotation); // Rotate by the calculated angle
    stroke(0);
    fill(this.colour);
    // Draw the rectangle centered on its position
    rect(0 - this.currentSize / 2, 0 - this.currentSize / 2, this.currentSize, this.currentSize);
    pop(); // Restore previous drawing state
  }
}

